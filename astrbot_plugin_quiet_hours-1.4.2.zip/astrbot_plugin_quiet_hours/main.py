"""静默时段：在指定时间把群里的回复压缩到最短，并关掉插件指令通道。

做四件事，按省下的量排序：
1. 砍掉工具定义（工具 schema 往往比回复本身还长）
2. 换成极简系统提示词（丢弃人格描述）
3. 只保留最近 N 轮上下文
4. 超长回复按字数截断

另外在静默时段拦截指令通道：除白名单外，所有插件指令都不执行、不回复。
纯聊天和表情包回复（关键词/透传类插件）不受影响。
作用范围按平台过滤，WebUI 等自用会话默认完全不受影响。
"""

import logging
import re
from datetime import datetime, time as dtime, timedelta

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import Plain
from astrbot.api.provider import ProviderRequest
from astrbot.api.star import Context, Star
from astrbot.core.message.message_event_result import MessageChain, ResultContentType
from astrbot.core.star.filter.command import CommandFilter
from astrbot.core.star.star_handler import EventType, star_handlers_registry

LOG = logging.getLogger("astrbot")

NIGHT_SYSTEM = """现在是低活跃时段，回复必须极简。

规则：
1. 只回答被问到的部分，一到两句话结束
2. 总长不超过 40 字，不举例、不延展、不补充背景
3. 不用语气词、不用表情、不寒暄、不反问
4. 能一句话说清就不说第二句

回答质量不能因为短而变差，但也不需要照顾气氛。"""


class QuietHours(Star):
    def __init__(self, context: Context, config: dict):
        super().__init__(context)
        self.config = config or {}
        self._ranges: list[tuple[dtime, dtime]] | None = None
        self._logged_sessions: set[str] = set()
        self._bypass_until: datetime | None = None
        self._hint_last: dict[str, datetime] = {}
        self._prompt_cleared: set[str] = set()

    # ── 时段判断 ──────────────────────────────────────────

    @staticmethod
    def _to_time(text: str) -> dtime:
        text = text.strip().replace("：", ":")
        hour, minute = text.split(":")
        return dtime(int(hour), int(minute))

    def _parse_ranges(self) -> list[tuple[dtime, dtime]]:
        if self._ranges is not None:
            return self._ranges
        raw = str(self.config.get("ranges", "") or "").replace("，", ",")
        parsed = []
        for part in raw.split(","):
            part = part.strip()
            if not part or "-" not in part:
                continue
            left, right = part.split("-", 1)
            try:
                parsed.append((self._to_time(left), self._to_time(right)))
            except Exception:
                logger.warning(f"[静默时段] 无法解析时间段：{part}")
        self._ranges = parsed
        return parsed

    def _list_conf(self, key: str, default: str = "") -> list[str]:
        raw = self.config.get(key, default) or ""
        items = raw if isinstance(raw, (list, tuple)) else str(raw).replace("，", ",").split(",")
        return [str(x).strip().lower() for x in items if str(x).strip()]

    @staticmethod
    def _platform_of(event: AstrMessageEvent | None) -> str:
        if event is None:
            return ""
        name = ""
        getter = getattr(event, "get_platform_name", None)
        if callable(getter):
            try:
                name = str(getter() or "")
            except Exception:
                name = ""
        if not name:
            name = str(getattr(event, "unified_msg_origin", "") or "").split(":", 1)[0]
        return name.strip().lower()

    def _in_scope(self, event: AstrMessageEvent | None) -> bool:
        """静默只作用于指定平台，自用会话（默认 WebUI）不参与。"""
        if event is None:
            return True
        name = self._platform_of(event)
        if name and name in self._list_conf("exclude_platforms", "webchat"):
            return False
        only = self._list_conf("only_platforms")
        if only and name not in only:
            return False
        if self.config.get("only_group_chat", False):
            umo = str(getattr(event, "unified_msg_origin", "") or "")
            parts = umo.split(":")
            if len(parts) > 1 and parts[1] != "group":
                return False
        return True

    def _bypass_active(self, now_dt: datetime | None = None) -> bool:
        if self._bypass_until is None:
            return False
        now_dt = now_dt or datetime.now()
        if now_dt >= self._bypass_until:
            self._bypass_until = None
            return False
        return True

    def _in_quiet(self, now: dtime | None = None, event: AstrMessageEvent | None = None) -> bool:
        if not self.config.get("enabled", True):
            return False
        if self._bypass_active():
            return False
        if not self._in_scope(event):
            return False
        now = now or datetime.now().time()
        for start, end in self._parse_ranges():
            if start <= end:
                if start <= now < end:
                    return True
            elif now >= start or now < end:  # 跨午夜
                return True
        return False

    def _remain_minutes(self) -> int | None:
        """距离静默结束还有多少分钟，用于状态查询。"""
        now_dt = datetime.now()
        now = now_dt.time()
        best = None
        for start, end in self._parse_ranges():
            inside = (
                (start <= now < end)
                if start <= end
                else (now >= start or now < end)
            )
            if not inside:
                continue
            end_dt = datetime.combine(now_dt.date(), end)
            if end_dt <= now_dt:
                end_dt += timedelta(days=1)
            delta = int((end_dt - now_dt).total_seconds() // 60)
            best = delta if best is None else min(best, delta)
        return best

    # ── 指令通道拦截 ──────────────────────────────────────

    def _wake_prefixes(self) -> list[str]:
        try:
            cfg = self.context.get_config()
            prefixes = cfg.get("wake_prefix", ["/"])
            if isinstance(prefixes, str):
                return [prefixes]
            return [str(p) for p in prefixes if str(p)]
        except Exception:
            return ["/"]

    def _command_names(self) -> set[str]:
        """全部已注册指令名（含别名与子指令末段）。

        这里不用 only_activated=True：它依赖 star_map 的模块路径登记，
        拿不到时会返回空集合，拦截面会静默失效。
        """
        names: set[str] = set()
        handlers = star_handlers_registry.get_handlers_by_event_type(
            EventType.AdapterMessageEvent, only_activated=False
        )
        for handler in handlers:
            for flt in handler.event_filters:
                if not isinstance(flt, CommandFilter):
                    continue
                try:
                    candidates = flt.get_complete_command_names()
                except Exception:
                    candidates = []
                for name in candidates:
                    if name:
                        names.add(name)
                        names.add(name.split(" ")[-1])
        return names

    def _command_name(self, event: AstrMessageEvent) -> str | None:
        """判断这条消息是不是指令调用，返回指令名。

        waking_check 在指令前缀唤醒时会把前缀从 message_str 里剥掉，
        所以裸文本要和指令表比对；带前缀的形式（@ 后接指令）则直接判定。
        """
        if not getattr(event, "is_at_or_wake_command", False):
            return None
        getter = getattr(event, "get_message_str", None)
        raw = str((getter() if callable(getter) else getattr(event, "message_str", "")) or "").strip()
        if not raw:
            return None

        stripped, had_prefix = raw, False
        for prefix in self._wake_prefixes():
            if prefix and raw.startswith(prefix):
                stripped = raw[len(prefix) :].strip()
                had_prefix = True
                break
        first = stripped.split(" ")[0] if stripped else ""
        if not first:
            return None
        if had_prefix:
            return first
        return first if first in self._command_names() else None

    @filter.event_message_type(filter.EventMessageType.ALL, priority=10000)
    async def guard_commands(self, event: AstrMessageEvent):
        """静默时段关闭指令通道，白名单指令除外。"""
        if not self.config.get("block_commands", True):
            return
        if not self._in_quiet(event=event):
            return

        name = self._command_name(event)
        if not name:
            return  # 普通聊天、表情包回复放行

        allow = set(self._list_conf("command_allowlist"))
        if name in allow or name.split(" ")[0] in allow or name.split(" ")[-1] in allow:
            return

        LOG.warning(
            f"[静默时段] 拦截指令 {name} 来自 {event.get_sender_id()} @ {event.unified_msg_origin}"
        )
        hint = str(self.config.get("block_hint", "") or "").strip()
        if hint and self._allow_hint(event.unified_msg_origin):
            # 先直接发出提示，再终止传播；stop_event 会跳过 respond 阶段
            await event.send(MessageChain([Plain(hint)]))
        event.stop_event()

    def _allow_hint(self, session: str) -> bool:
        """同一会话内提示语有冷却，避免连续发指令时刷屏。"""
        cooldown = int(self.config.get("hint_cooldown_seconds", 60) or 0)
        now = datetime.now()
        last = self._hint_last.get(session)
        if cooldown > 0 and last is not None and (now - last).total_seconds() < cooldown:
            return False
        self._hint_last[session] = now
        return True

    # ── 请求阶段：省 token ────────────────────────────────

    @filter.on_llm_request(priority=100000)
    async def compress_request(self, event: AstrMessageEvent, req: ProviderRequest) -> None:
        # 人格在 agent 构建阶段（astr_main_agent.py:1070）就已写入，此钩子覆盖即可生效。
        # priority 取大值表示先执行：先定下极简基线与工具范围，
        # 其它插件的提示词追加在之后，再由 enforce_minimal_prompt(-5000) 统一收尾。
        if not self._in_quiet(event=event):
            self._logged_sessions.clear()
            return

        saved = []

        if self.config.get("disable_tools", True) and getattr(req, "func_tool", None):
            keep_tools = set(self._list_conf("keep_tools"))
            toolset = req.func_tool
            if keep_tools:
                before = len(toolset.tools)
                toolset.tools = [t for t in toolset.tools if t.name in keep_tools]
                saved.append(f"工具 {before}→{len(toolset.tools)}")
                if not toolset.tools:
                    req.func_tool = None
            else:
                req.func_tool = None
                saved.append("工具")

        if self.config.get("strip_persona", True):
            req.system_prompt = NIGHT_SYSTEM
            saved.append("人格")

        keep = int(self.config.get("keep_context_turns", 1) or 0)
        if req.contexts:
            before = len(req.contexts)
            if keep <= 0:
                req.contexts = []
            else:
                tail = req.contexts[-keep * 2 :]
                while tail and tail[0].get("role") != "user":
                    tail.pop(0)
                req.contexts = tail
            if len(req.contexts) < before:
                saved.append(f"上下文 {before}→{len(req.contexts)}")

        sid = event.unified_msg_origin
        if sid not in self._logged_sessions:
            self._logged_sessions.add(sid)
            LOG.info(f"[静默时段] 已压缩请求：{'、'.join(saved) or '无变化'}")

    @filter.on_llm_request(priority=-5000)
    async def enforce_minimal_prompt(
        self, event: AstrMessageEvent, req: ProviderRequest
    ) -> None:
        """跑在其它插件的提示词注入之后，把追加内容一并清掉。

        meme_manager 在 priority=99999 无条件往 system_prompt 追加约 1900 字选图说明，
        即使它的工具已被禁用也照追不误。这里兜底覆盖，才是真的省下这部分。
        """
        if not self.config.get("strip_persona", True):
            return
        if not self._in_quiet(event=event):
            return
        if self._list_conf("keep_tools"):
            return  # 保留工具时不能抹，表情包需要那段说明
        if req.system_prompt != NIGHT_SYSTEM:
            req.system_prompt = NIGHT_SYSTEM
            if event.unified_msg_origin not in self._prompt_cleared:
                self._prompt_cleared.add(event.unified_msg_origin)
                LOG.info("[静默时段] 已清除其它插件追加的提示词")

    # ── 发送阶段：限制长度 ────────────────────────────────

    @filter.on_decorating_result(priority=-1000)
    async def trim_result(self, event: AstrMessageEvent) -> None:
        if not self._in_quiet(event=event):
            return
        limit = int(self.config.get("max_reply_chars", 60) or 0)
        if limit <= 0:
            return

        result = event.get_result()
        if not result:
            return
        # 只裁 LLM 生成的回复，指令输出保持原样
        if result.result_content_type not in (
            ResultContentType.LLM_RESULT,
            ResultContentType.STREAMING_FINISH,
        ):
            return

        chain = result.chain
        if isinstance(chain, str):
            if len(chain) > limit:
                result.chain = chain[:limit].rstrip() + "…"
            return
        if not isinstance(chain, list):
            return

        trimmed = []
        remaining = limit
        truncated = False
        for component in chain:
            if isinstance(component, Plain):
                if len(component.text) > remaining:
                    trimmed.append(Plain(component.text[:remaining].rstrip() + "…"))
                    truncated = True
                    break
                remaining -= len(component.text)
            trimmed.append(component)
        if truncated:
            result.chain = trimmed

    # ── 指令 ──────────────────────────────────────────────

    @staticmethod
    def _arg_text(event: AstrMessageEvent) -> str:
        msg = (getattr(event, "message_str", "") or "").strip()
        parts = msg.split(maxsplit=1)
        return parts[1].strip() if len(parts) > 1 else ""

    def _parse_minutes(self, text: str) -> int | None:
        text = text.strip().lower()
        if not text:
            return None
        unit = 1
        if text.endswith("小时") or text.endswith("h"):
            unit = 60
            text = text[:-2] if text.endswith("小时") else text[:-1]
        elif text.endswith("分钟"):
            text = text[:-2]
        digits = "".join(c for c in text if c.isdigit())
        if not digits:
            return None
        return int(digits) * unit

    @filter.permission_type(filter.PermissionType.ADMIN)
    @filter.command("静默状态", alias={"省电状态"})
    async def status(self, event: AstrMessageEvent):
        """查看静默时段的当前状态"""
        enabled = self.config.get("enabled", True)
        ranges = self.config.get("ranges", "")
        active = self._in_quiet(event=event)
        bypassing = self._bypass_active()

        lines = ["🌙 静默时段", ""]
        lines.append(f"开关：{'开' if enabled else '关'}")
        lines.append(f"时段：{ranges or '未设置'}")
        if bypassing:
            left = int((self._bypass_until - datetime.now()).total_seconds() // 60)
            lines.append(f"当前：已临时关闭，{left} 分钟后恢复")
        elif active:
            remain = self._remain_minutes()
            lines.append("当前：静默中" + (f"，还有 {remain} 分钟结束" if remain is not None else ""))
        elif not self._in_scope(event):
            lines.append("当前：正常模式（本会话不在静默范围内）")
        else:
            lines.append("当前：正常模式")

        scope = self._list_conf("exclude_platforms", "webchat")
        lines.append("")
        lines.append(f"生效范围：全部平台，排除 {'、'.join(scope) or '无'}")
        lines.append(
            f"压缩项：人格 {'改为极简' if self.config.get('strip_persona', True) else '保留'}"
            f" · 工具 {'禁用' if self.config.get('disable_tools', True) else '保留'}"
            f" · 上下文 {self.config.get('keep_context_turns', 1)} 轮"
            f" · 回复上限 {self.config.get('max_reply_chars', 60)} 字"
        )
        blocked = "拦截" if self.config.get("block_commands", True) else "放行"
        allow = self._list_conf("command_allowlist")
        lines.append(f"指令通道：{blocked}，白名单 {'、'.join(allow) or '无'}")
        keep_tools = self._list_conf("keep_tools")
        if self.config.get("disable_tools", True):
            lines.append(f"保留工具：{'、'.join(keep_tools) or '无'}")
        yield event.plain_result("\n".join(lines))

    @filter.permission_type(filter.PermissionType.ADMIN)
    @filter.command("静默结束", alias={"关闭静默"})
    async def end_quiet(self, event: AstrMessageEvent):
        """提前结束静默，可带分钟数，例如：静默结束 120"""
        minutes = self._parse_minutes(self._arg_text(event))
        remain = self._remain_minutes()

        if minutes is None:
            if remain is None:
                yield event.plain_result("当前不在静默时段，无需结束。")
                return
            minutes = remain
        if minutes <= 0:
            yield event.plain_result("时长要大于 0 分钟。")
            return

        self._bypass_until = datetime.now() + timedelta(minutes=minutes)
        self._logged_sessions.clear()
        LOG.info(f"[静默时段] 管理员 {event.get_sender_id()} 临时关闭 {minutes} 分钟")
        until = self._bypass_until.strftime("%H:%M")
        yield event.plain_result(f"已临时关闭静默，{until} 后按配置自动恢复。发「静默开启」可立即恢复。")

    @filter.permission_type(filter.PermissionType.ADMIN)
    @filter.command("静默开启", alias={"恢复静默"})
    async def resume_quiet(self, event: AstrMessageEvent):
        """取消临时关闭，立即回到配置的静默判断"""
        had = self._bypass_active()
        self._bypass_until = None
        self._logged_sessions.clear()

        if not self.config.get("enabled", True):
            yield event.plain_result("临时关闭已取消，但插件开关处于关闭状态，需要在配置里启用。")
            return
        if self._in_quiet(event=event):
            remain = self._remain_minutes()
            tail = f"，还有 {remain} 分钟结束" if remain is not None else ""
            yield event.plain_result(f"已恢复静默{tail}。")
            return
        head = "临时关闭已取消。" if had else "本来就没在临时关闭状态。"
        yield event.plain_result(f"{head}当前不在静默时段，到点会自动生效。")
