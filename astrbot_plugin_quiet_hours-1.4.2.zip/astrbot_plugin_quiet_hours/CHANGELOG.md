# 更新日志

版本号遵循语义化版本：`MAJOR.MINOR.PATCH`。
`MINOR` 是新增能力或行为变化，`PATCH` 是修复。

---

## 1.4.2 — 2026-10-22

### 修复

- 日志在部分部署中完全不输出。插件原先通过 `astrbot.api.logger` 拿 logger，
  该对象会按调用栈模块名去 `star_map` 里找插件身份，手动重载后模块名对不上时
  会落到兜底 logger，而 loguru 的格式串依赖 `extra.plugin_tag` 等字段，
  缺字段的记录会被 `catch=True` 静默丢弃。现统一改用 `logging.getLogger("astrbot")`。

### 变更

- 移除临时落盘探针（`/tmp/qh_probe.log`）。诊断期用它绕开日志系统确认拦截链路，
  问题定位后不再保留。

---

## 1.4.1 — 2026-10-22

### 修复

- 指令匹配整体失效：`_match_command` 调用
  `get_handlers_by_event_type(..., only_activated=True)`，该方法内部按
  `star_map[handler_module_path]` 判活，取不到就跳过，导致指令表为空、
  任何指令都判为"非指令"。改为 `only_activated=False`，并补上
  `wake_prefix` 判定（`waking_check` 会在前缀唤醒时把前缀从 `message_str` 剥掉，
  所以裸文本需要和指令表比对）。
- 提示语发不出去：`event.send()` 的签名是 `send(message: MessageChain)`，
  此前传入的是 `event.plain_result()` 返回的 `MessageEventResult`，类型不符。
- 配置文件若带 UTF-8 BOM，整份配置可能解析失败并静默回落成默认值，
  表现为"改了 `block_hint` 却没提示"。现输出不带 BOM。

### 变更

- `keep_tools` 默认值由 `search_memes_tool` 改为空。
  实测表情包工具的 schema 约 331 token，而 `meme_manager` 的选图说明
  （`inject_meme_prompt`，priority 99999）约 1900 字、近 1200 token，
  且无论工具是否启用都会追加。保留表情包的边际成本约 1500 token/请求，
  默认不再保留。

---

## 1.4.0 — 2026-10-22

### 新增

- `keep_tools`：静默时仍保留给模型的工具白名单，其余移除。
- `enforce_minimal_prompt`（priority -5000）：在所有插件的提示词注入之后收尾，
  把 `system_prompt` 重置回极简指令，用于清掉其他插件无条件追加的内容。

### 变更

- `compress_request` 优先级由 `-1000` 提到 `100000`，先于其他插件的注入执行，
  由后置钩子统一收尾。原先的负优先级会导致"我们覆盖别人"和"别人覆盖我们"
  取决于插件加载顺序，行为不稳定。

---

## 1.3.0 — 2026-10-22

### 新增

- **指令通道拦截** `guard_commands`（priority 10000）：静默时段内，命中已注册指令
  即 `stop_event()`，后续 process_stage 全部跳过，指令不执行、不回复。
- `command_allowlist`：默认放行 `静默状态`、`静默结束`、`静默开启`。
  这一项是必需的，否则静默期间无法解除静默。
- `block_hint`：指令被拦时的提示语，默认留空（完全不出声）。
- `hint_cooldown_seconds`：同一会话内提示语的冷却，默认 60 秒，避免连发指令时刷屏。

### 说明

- 只针对指令通道。纯聊天不受影响，走关键词/透传的插件（如表情包回复）也不受影响。
- 指令本身大多不经过 LLM（由 handler 直接回复），因此拦截省下的不是 token，
  而是行为层面的安静。真正省 token 的仍是 1.0.0 的那四项。

---

## 1.2.0 — 2026-10-22

### 新增

- `/静默结束 [分钟]`（管理员）：提前结束静默。不带参数则豁免到本段自然结束，
  带数字则临时关闭指定分钟数，支持 `120`、`30分钟`、`2小时` 三种写法。
- `/静默开启`（管理员）：取消豁免，立即回到配置判断。

### 说明

- 豁免状态存在内存（`_bypass_until`），不动配置文件，重启自动归零，
  不会留下"忘了改回来"的状态。

---

## 1.1.0 — 2026-10-22

### 新增

- 平台范围过滤，解决"夜里在 WebUI 干活也被静默"的问题：
  - `exclude_platforms`：默认 `webchat`，WebUI 会话永不压缩
  - `only_platforms`：留空表示除排除项外全部生效
  - `only_group_chat`：只对群聊生效，私聊不压缩

### 修复

- 静默判断原先只看时间、不看来源，任何平台的自用会话都会被当夜间群聊处理，
  表现为"到了点机器人忽然不干活了"。

---

## 1.0.0 — 初始版本

### 新增

- 时间段配置 `ranges`，支持多段与跨午夜（`23:30-07:00`）。
- 请求期压缩，四项可独立开关：
  - `disable_tools`：清空 `req.func_tool`，工具 schema 通常是最大的一笔固定开销
  - `strip_persona`：用极简指令替换系统提示词
  - `keep_context_turns`：只保留最近 N 轮上下文，0 为不带
  - `max_reply_chars`：按字数截断回复，仅作用于 `LLM_RESULT` / `STREAMING_FINISH`
- `/静默状态`（管理员）：查看是否静默中、剩余分钟、各项压缩的当前取值。
- 指令输出不截断，只处理 LLM 生成的回复。

---

## 已知限制

- 工具被禁用后，依赖工具的功能（联网、点歌、搜图等）在静默时段失效，这是设计代价。
- 关闭工具后模型可能口头声称"我帮你查了/点了"，实际什么都没做。
- 时间段解析结果做了缓存，改完配置需要重载插件。
- 若供应商支持 prompt caching，且工具块处于稳定前缀，日常重复请求本已命中缓存，
  静默时省下的实际费用会低于按 token 单价的估算。
